#include "header.h"
void fornisci(struct Buffer* p){
    enter_monitor(&(p->m));

    while(p->livello_scorte == DIM){
        wait_condition(&(p->m),VARCOND_FORNITORI);
    }

    int index = 0;
    while(p->buffer[index].stato != LIBERO && index<DIM){
        index++;
    }
    
    p->buffer[index].stato = IN_USO;
    leave_monitor(&(p->m));

    sleep(2);
    p->buffer[index].id_fornitore = getpid();
    printf("Fornito prodotto ID: %d [%d]\n",p->buffer[index].id_fornitore,index);

    enter_monitor(&(p->m));
    p->buffer[index].stato = OCCUPATO;
    (p->livello_scorte) = (p->livello_scorte) + 1;
    printf("Prodotti disponibili: %d\n",p->livello_scorte);

    signal_condition(&(p->m),VARCOND_CLIENTI);
    leave_monitor(&(p->m));
    
}


void acquista(struct Buffer*p){
    enter_monitor(&(p->m));
    while(p->livello_scorte == 0){
        wait_condition(&(p->m),VARCOND_CLIENTI);
    }

    int index = 0;
    while(p->buffer[index].stato != OCCUPATO && index<DIM){
        index++;
    }

    p->buffer[index].stato = IN_USO;
    
    leave_monitor(&(p->m));

    sleep(2);
    printf("Acquistato prodotto ID: %d[%d]\n",p->buffer[index].id_fornitore,index);
    p->buffer[index].id_fornitore = 0;
    
    enter_monitor(&(p->m));
    p->buffer[index].stato = LIBERO;
    (p->livello_scorte) = (p->livello_scorte) - 1;
    

    signal_condition(&(p->m),VARCOND_FORNITORI);
    leave_monitor(&(p->m));
    
}