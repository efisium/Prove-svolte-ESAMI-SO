#ifndef _HEAD_
#define _HEAD_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

#include "monitor_signal_continue.h"

#define N_FORNITORI 10
#define N_CLIENTI 10
#define DIM 100
#define VARCOND_FORNITORI 0
#define VARCOND_CLIENTI 1
#define LIBERO 0
#define OCCUPATO 1
#define IN_USO 2

typedef struct{
    unsigned int id_fornitore;
    unsigned int stato;
}scaffale;

struct Buffer{
    scaffale buffer[DIM];
    int livello_scorte;
    Monitor m;
};

void fornisci(struct Buffer*);
void acquista(struct Buffer*);

#endif