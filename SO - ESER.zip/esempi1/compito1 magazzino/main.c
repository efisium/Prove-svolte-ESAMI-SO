#include "header.h"

int main(){
    pid_t pid;
    int status;

    //SHM KEY
    key_t shm_key = IPC_PRIVATE;

    //CREAZIONE SHM
    int ds_shm = shmget(shm_key,sizeof(struct Buffer),IPC_CREAT|0664);

    //PUNTATORE SHM
    struct Buffer* p = (struct Buffer*)shmat(ds_shm,NULL,0);
    for(int i=0;i<DIM;i++){
        p->buffer[i].id_fornitore=0;
        p->buffer[i].stato = LIBERO;
    }
    p->livello_scorte = 0;

    init_monitor(&(p->m),2);

    //CREAZIONE PROCESSI
    
    // ** FORNITORI **
    for(int i=0;i<N_FORNITORI;i++){
        pid = fork();
        if(pid == 0){
            //Processo fornitore
            for(int j=0;j<15;j++){
                sleep(1);
                fornisci(p);
            }
            exit(0);
        }
    }

    // ** CLIENTI **
    for(int i=0;i<N_CLIENTI;i++){
        pid = fork();
        if(pid == 0){
            //Processo cliente
            for(int j=0;j<15;j++){
                sleep(4);
                acquista(p);
            }
            exit(0);
        }
        
    }

    for(int i=0;i<N_FORNITORI + N_CLIENTI;i++){
        pid = wait(&status);
        if(pid<0){
            printf("Errore terminazione processo.\n");
        }
        printf("Processo %d terminato con stato:%d",pid,status);
    }


    remove_monitor(&(p->m));
    shmctl(ds_shm,IPC_RMID,0);
    return 0;
}

