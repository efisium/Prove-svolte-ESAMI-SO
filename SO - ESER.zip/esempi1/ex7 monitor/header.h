#ifndef _HEAD_
#define _HEAD_


#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/ipc.h>
#include "monitor_signal_continue.h"
#define DIM_BUFFER 10

typedef struct {
    int buffer[DIM_BUFFER];
    int testa; int coda;
    Monitor m;      // utilizzare la libreria di procedure allegate
    int cont;
} PriorityProdCons; 

#define VAR_COND_PROD_ALTA 0
#define VAR_COND_PROD_BASSA 1
#define VAR_COND_CONS 2
#define RAND_MAX_1 12

void inizializza_prod_cons(PriorityProdCons * p);
void produci_alta_prio(PriorityProdCons * p);
void produci_bassa_prio(PriorityProdCons * p);
void consuma(PriorityProdCons * p);
void rimuovi_prod_cons(PriorityProdCons * p);


#endif 
