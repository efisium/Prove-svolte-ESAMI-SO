#include "header.h"

void inizializza_prod_cons(PriorityProdCons *p){
    for(int i=0;i<3;i++){
        p->buffer[i]=0;
    }
    p->testa = 0;
    p->coda = 0;
    p->cont = 0;
    init_monitor(&(p->m),3);
}

void rimuovi_prod_cons(PriorityProdCons *p){
    remove_monitor(&(p->m));
}

void produci_alta_prio(PriorityProdCons *p){
    enter_monitor(&(p->m));
    while( p->cont == DIM_BUFFER){
        wait_condition(&(p->m),VAR_COND_PROD_ALTA);
    }
    
    //GENERA VALORE - PRODUCI
    srand(time(NULL)+10);
    p->buffer[p->testa] = rand()%(RAND_MAX_1+1);
    (p->cont)++;
    printf("Valore prodotto ALTA PRIORITA': %d, Contatore aggiornato: %d\n",p->buffer[p->testa],p->cont);
    p->testa = (p->testa+1) % DIM_BUFFER;
    
    signal_condition(&(p->m),VAR_COND_CONS);
    leave_monitor(&(p->m));
}

void produci_bassa_prio(PriorityProdCons *p){
    enter_monitor(&(p->m));
    while( p->cont == DIM_BUFFER /*|| p->m.cond_counts[VAR_COND_PROD_ALTA]!=0*/){
        /*if(p->m.cond_counts[VAR_COND_PROD_ALTA]!=0){
            printf("Do la priorita' ad ALTA\n");
        }*/
        wait_condition(&(p->m),VAR_COND_PROD_BASSA);
    }
    
    //GENERA VALORE - PRODUCI
    srand(time(NULL)+10);
    p->buffer[p->testa] = 13 + rand()%(RAND_MAX_1+1);
    (p->cont)++;
    printf("Valore prodotto BASSA PRIORITA': %d, Contatore aggiornato: %d\n",p->buffer[p->testa],p->cont);
    p->testa = (p->testa+1) % DIM_BUFFER;
    
    
    signal_condition(&(p->m),VAR_COND_CONS);
    leave_monitor(&(p->m));
}

void consuma(PriorityProdCons *p){
    enter_monitor(&(p->m));
    /*while( p->cont == 0){
        wait_condition(&(p->m),VAR_COND_CONS);
    }*/
    
    //STAMPA VALORE - CONSUMA
    printf("Valore nel buffer: %d\n",p->buffer[p->coda]);
    p->coda = (p->coda+1) % DIM_BUFFER;
    (p->cont)--;

    if(p->m.cond_counts[VAR_COND_PROD_ALTA]!=0){
        signal_condition(&(p->m),VAR_COND_PROD_ALTA);
    }else if(p->m.cond_counts[VAR_COND_PROD_BASSA]!=0){
        signal_condition(&(p->m),VAR_COND_PROD_BASSA);
    }

    leave_monitor(&(p->m));
}

