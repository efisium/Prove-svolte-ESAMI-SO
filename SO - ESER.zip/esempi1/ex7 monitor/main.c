#include "header.h"

int main(){
    int pid,status;
    //SHM
    int shm_id = shmget(IPC_PRIVATE,sizeof(PriorityProdCons),IPC_CREAT|0664);
    PriorityProdCons *p = shmat(shm_id,NULL,0);
    inizializza_prod_cons(p);

    //FORK

    //PROCESSO PRODUTTORE ALTA PRIORITA'
    pid = fork();
    if(pid == 0){
        for(int i=0;i<6;i++){
            sleep(2);
            produci_alta_prio(p);
            
        }
        exit(0);
    }

    //PROCESSO PRODUTTORE BASSA PRIORITA'
    pid = fork();
    if(pid == 0){
        for(int i=0;i<6;i++){
            sleep(1);
            produci_bassa_prio(p);
            
        }
        exit(0);
    }

    //PROCESSO CONSUMATORE
    pid = fork();
    if(pid == 0){
        //sleep(3);
        for(int i=0;i<14;i++){
            sleep(5);
            consuma(p);
        }
        exit(0);
    }

    //WAIT DEI 3 PROCESSI GENERATI
    for (int k=0; k<3;k++) {

		pid=wait(&status);
		if (pid==-1) {
			 perror("errore");
		} else {
			 printf ("Figlio n.ro %d è morto con status= %d \n ",pid,status);
		}
	}

    //Deallocazione Monitor/IPC
    rimuovi_prod_cons(p);
    shmctl(shm_id,IPC_RMID,0);

    return 0;
}