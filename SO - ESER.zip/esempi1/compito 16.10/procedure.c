#include "header.h"


void msgsend(int queue1){
    Message msg;
    msg.type = MSG_TYPE;
    msg.pid = getpid();
    msgsnd(queue1,(void*)&msg,sizeof(Message)-sizeof(long),IPC_NOWAIT);
    printf("[CLIENT %d] Messaggio inviato <%d>\n",getpid(),msg.pid);
}
void msgrcv_f(int queue1,int server){
    Message msg;
    int val;
    while(1){
        sleep(1);
        msgrcv(queue1,(void*)&msg,sizeof(Message)-sizeof(long),server,0);
        printf("[SERVER <%d>] Messaggio ricevuto: %d\n",server,msg.pid);
        if(msg.pid == 1) break;
    }
}

void msgbalance(int queue1){
    Message msg;
    while(1){
        for(int i=1;i<=3;i++){
            msgrcv(queue1,(void*)&msg,sizeof(Message)-sizeof(long),MSG_TYPE,0);
            switch(i){
                case 1:
                {
                    //SERVER 1
                    msg.type = SERVER_1;
                    printf("[BALANCE] Invio messaggio al server 1... (%d)\n",msg.pid);
                    msgsnd(queue1,(void*)&msg,sizeof(Message)-sizeof(long),IPC_NOWAIT);
                }break;

                case 2:
                {
                    //SERVER 2
                    msg.type = SERVER_2;
                    printf("[BALANCE] Invio messaggio al server 2... (%d)\n",msg.pid);
                    msgsnd(queue1,(void*)&msg,sizeof(Message)-sizeof(long),IPC_NOWAIT);
                }break;

                case 3:
                {
                    //SERVER 3
                    msg.type = SERVER_3;
                    printf("[BALANCE] Invio messaggio al server 3... (%d)\n",msg.pid);
                    msgsnd(queue1,(void*)&msg,sizeof(Message)-sizeof(long),IPC_NOWAIT);
                }break;
            }
        }
        if(msg.pid == 1) break;
        /*msgrcv(queue1,(void*)&msg,sizeof(Message)-sizeof(long),MSG_TYPE,0);
        msg.type = SERVER_1;
        printf("[BALANCE] Invio messaggio al server 1... (%d)\n",msg.pid);
        msgsnd(queue1,(void*)&msg,sizeof(Message)-sizeof(long),IPC_NOWAIT);

        msgrcv(queue1,(void*)&msg,sizeof(Message)-sizeof(long),MSG_TYPE,0);
        msg.type = SERVER_2;
        printf("[BALANCE] Invio messaggio al server 2... (%d)\n",msg.pid);
        msgsnd(queue1,(void*)&msg,sizeof(Message)-sizeof(long),IPC_NOWAIT);


        msgrcv(queue1,(void*)&msg,sizeof(Message)-sizeof(long),MSG_TYPE,0);
        msg.type = SERVER_3;
        printf("[BALANCE] Invio messaggio al server 3... (%d)\n",msg.pid);
        msgsnd(queue1,(void*)&msg,sizeof(Message)-sizeof(long),IPC_NOWAIT);*/
    }
}