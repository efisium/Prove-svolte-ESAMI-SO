#ifndef _HEAD_
#define _HEAD_

#include <stdio.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <time.h>
#include <string.h>

#define NUM_CLIENT 3
#define NUM_SERVER 3
#define MSG_TYPE 4
#define SERVER_1 1
#define SERVER_2 2
#define SERVER_3 3

typedef struct{
    long type;
    int pid;
}Message;

void msgsend(int queue1);
void msgrcv_f(int queue1,int server);
void msgbalance(int queue1);

#endif