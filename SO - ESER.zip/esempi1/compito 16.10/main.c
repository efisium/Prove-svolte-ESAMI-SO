#include "header.h"

int main(){
    pid_t pid,pid_balancer,pid_server[NUM_SERVER];
    int status;

    //QUEUE
    key_t queue_key1 = IPC_PRIVATE;
    int queue_1 = msgget(queue_key1,IPC_CREAT|0664);

    printf("Avvio Main...     ID CODA <%d> \n",queue_1);


    //**** CREAZIONE PROCESSI
    //PROCESSI CLIENT
    for(int i=0;i<3;i++){
        pid = fork();
        if(pid == 0){
            printf("[CLIENT] Avvio %d...\n",getpid());
            sleep(3);
            for(int j=0;j<4;j++){
                sleep(5);
                msgsend(queue_1);
                printf("[CLIENT %d] Invio messaggio n. %d\n",i,j);
            }
            exit(0);
        }
    }

    //PROCESSI SERVER
     for(int i=0;i<NUM_SERVER;i++){
        pid_server[i] = fork();
        if(pid_server[i] == 0){
            printf("[SERVER <%d>] Avvio %d...\n",i,getpid());
            sleep(3);
            msgrcv_f(queue_1,i+1);
            exit(0);
        }
    }

    //PROCESSO BALANCER
    pid_balancer = fork();
    if(pid_balancer == 0){
        printf("[BALANCER] Avvio %d...\n",getpid());
        sleep(3);
        msgbalance(queue_1);
        exit(0);
    }

    for(int i=0;i<NUM_CLIENT;i++){
        pid = wait(&status);
        if(pid<0){
            perror("ERRORE WAIT\n");
            exit(1);
        }
        printf("[MAIN]Processo CLIENT %d terminato con stato: %d\n",pid,status);
    }

    
    Message msg_exit;
    msg_exit.pid = 1;
    msg_exit.type = MSG_TYPE;
    
    for(int k=0;k<NUM_SERVER;k++){
        printf("[MAIN] Invio exit message...\n");
        msgsnd(queue_1,(void*)&msg_exit,sizeof(Message)-sizeof(long),0);
    }
    for(int i=0;i<NUM_SERVER+1;i++){
        pid = wait(&status);
        if(pid<0){
            perror("ERRORE WAIT\n");
            exit(1);
        }
        printf("processo %d terminato con stato: %d\n",pid,status);
    }
    msgctl(queue_1,IPC_RMID,0);
    return 0;
}