#include "header.h"

int affitta(struct Monitor * m, int id_film){
    int status = NON_DISP;
    int i;
    pthread_mutex_lock(&m->mutex);
    //printf("Entro nel mutex \n");
    while(1){
        for(i=0;i<DIM_BUFFER;i++){
            if(m->dvd[i].identificativo_film == id_film && m->dvd[i].stato == DISPONIBILE){ 
                status = TROVATO;
                break;
            }
        }
        if(status == TROVATO) break;
        switch(id_film){

            case 1:
            { 
                printf("Attendo disponibilita' filn n.%d...\n",id_film);
                pthread_cond_wait(&m->ok_film_1,&m->mutex);
                break;
            }

            case 2:
            {
                printf("Attendo disponibilita' filn n.%d...\n",id_film);
                pthread_cond_wait(&m->ok_film_2,&m->mutex);
                break;
            }

            case 3:
            {
                printf("Attendo disponibilita' filn n.%d...\n",id_film);
                pthread_cond_wait(&m->ok_film_3,&m->mutex);
                break;
            }
        }
    }

    m->dvd[i].stato = AFFITTATO;
    pthread_mutex_unlock(&m->mutex);
    return m->dvd[i].identificativo_copia;
}
void restituisci(struct Monitor * m, int id_film, int id_copia){
    pthread_mutex_lock(&m->mutex);
    int i;
    for(i=0;i<DIM_BUFFER;i++){
        if(m->dvd[i].identificativo_film == id_film){
            if(m->dvd[i].identificativo_copia == id_copia){
                break;
            }
        }
    }
    printf("Ricerca finita indice trovato %d\n",i);
    m->dvd[i].stato = DISPONIBILE;
    switch(id_film){

            case 1:
            { 
                printf("Restituisco film n.%d...\n",id_film);
                pthread_cond_signal(&m->ok_film_1);
                break;
            }

            case 2:
            {
                printf("Restituisco film n.%d...\n",id_film);
                pthread_cond_signal(&m->ok_film_2);
                break;
            }

            case 3:
            {
                printf("Restituisco film n.%d...\n",id_film);
                pthread_cond_signal(&m->ok_film_3);
                break;
            }
    }
    pthread_mutex_unlock(&m->mutex);
}


void* stampa(void* g){
    struct Monitor * m = (struct Monitor*) g;
    for(int i=0;i<10;i++){
        sleep(1);
        printf("**********  STATO DVD **********\n");
        for(int j=0;j<DIM_BUFFER;j++){
            printf("STATO DVD %d: FILM <%d>  COPIA <%d>  STATO <%d>\n",j,m->dvd[j].identificativo_film,m->dvd[j].identificativo_copia,m->dvd[j].stato);
        }
    }
    pthread_exit(NULL);
}


void* RunFunction(void* g){
    printf("Nuovo thread in esecuzione...\n");
    struct Monitor* m = (struct Monitor*) g;
    int id;
    int copia;
    for(id=1;id<=3;id++){
        copia = affitta(m,id);
        printf("Affittato film ID:%d   N. copia:%d \n",id,copia);
        sleep(3);
        restituisci(m,id,copia);
        printf("Restituito film ID:%d   N. copia:%d \n",id,copia);
    }
    pthread_exit(NULL);
}

