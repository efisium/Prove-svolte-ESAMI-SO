#include "header.h"

int main(){
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_JOINABLE);

    //THREADS
    pthread_t thread[NUM_THREAD];
    pthread_t stamp;

    struct Monitor* m = malloc(sizeof(struct Monitor));

    for(int i=0;i<DIM_BUFFER/3;i++){
        m->dvd[i].identificativo_film = 1;
        m->dvd[i].identificativo_copia = i+1;
        m->dvd[i].stato = DISPONIBILE;
    }
    for(int i=0;i<DIM_BUFFER/3;i++){
        m->dvd[i+2].identificativo_film = 2;
        m->dvd[i+2].identificativo_copia = i+1;
        m->dvd[i+2].stato = DISPONIBILE;
    }
    for(int i=0;i<DIM_BUFFER/3;i++){
        m->dvd[i+4].identificativo_film = 3;
        m->dvd[i+4].identificativo_copia = i+1;
        m->dvd[i+4].stato = DISPONIBILE;
    }

    pthread_mutex_init(&m->mutex,NULL);
    pthread_cond_init(&m->ok_film_1,NULL);
    pthread_cond_init(&m->ok_film_2,NULL);
    pthread_cond_init(&m->ok_film_3,NULL);

    m->ok_produzione = 1;
    m->ok_consumo = 0;

    for(int i=0;i<NUM_THREAD;i++){
        pthread_create(&thread[i],&attr,RunFunction,(void*)m);
    }

    pthread_create(&stamp,&attr,stampa,(void*)m);

    for(int i=0;i<NUM_THREAD;i++){
        pthread_join(thread[i],NULL);
        printf ("Thread CONS n.ro %d terminato\n ",i);
    }

    pthread_join(stamp,NULL);

    pthread_attr_destroy(&attr);
    pthread_mutex_destroy(&m->mutex);
    pthread_cond_destroy(&m->ok_film_1);
    pthread_cond_destroy(&m->ok_film_2);
    pthread_cond_destroy(&m->ok_film_3);
    pthread_exit(NULL);
    return 0;
}