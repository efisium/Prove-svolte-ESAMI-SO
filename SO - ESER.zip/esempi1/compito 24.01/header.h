#ifndef _HEAD_
#define _HEAD_

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <errno.h>
#include <pthread.h>

#define NUM_THREAD 4
#define DIM_BUFFER 6
#define DISPONIBILE 0
#define AFFITTATO 1
#define TROVATO 1
#define NON_DISP 0

struct DVD{
    int identificativo_film;
    int identificativo_copia;
    int stato;
};

struct Monitor{
    struct DVD dvd[DIM_BUFFER];

    pthread_mutex_t mutex;
    pthread_cond_t ok_film_1;
    pthread_cond_t ok_film_2;
    pthread_cond_t ok_film_3;

    int ok_produzione;
    int ok_consumo;

};
int affitta(struct Monitor * m, int id_film);
void restituisci(struct Monitor * m, int id_film, int id_copia);
void* stampa(void* g);
void* RunFunction(void* g);


#endif