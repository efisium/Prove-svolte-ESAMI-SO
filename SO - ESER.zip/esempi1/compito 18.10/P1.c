#include "header.h"

int main(){
    //QUEUES
    key_t key_1 = ftok(".",'a');
    key_t key_2 = ftok(".",'b');

    int queue_1 = msgget(key_1,IPC_CREAT|0664);
    int queue_2 = msgget(key_2,IPC_CREAT|0664);

    //GENERAZIONW VETTORI
    int vett[NUM_OPERANDI];
    int ris[NUM_RIS_P1];

    

    Message msg;
    Message_ris msg_ris;

    for(int j=0;j<3;j++){
        sleep(2);
        printf("********** INIZIO CICLO %d**********    \n",j);
        for(int i=0;i<NUM_OPERANDI;i++){
            srand(time(NULL)*i);
            vett[i] = rand()%50;
        }
        for(int i=0;i<NUM_RIS_P1;i++){
            ris[i] = 0;
        }
        int k=0;
        //INVIO AL PROCESSO P2
        msg.type = P2_TYPE;
        for(int i=0;i<2;i++){
            msg.buffer[i] = vett[i+k];
        }
        k = k+2;
        msgsnd(queue_1,(void*)&msg,sizeof(Message)-sizeof(long),0);
        printf("<PROCESSO P1> Valori inviati a P2 <%d> <%d>\n",vett[0],vett[1]);


        //INVIO AL PROCESSO P3
        msg.type = P3_TYPE;
        for(int i=0;i<4;i++){
            msg.buffer[i] = vett[i+k];
        }
        k = k+4;
        msgsnd(queue_1,(void*)&msg,sizeof(Message)-sizeof(long),0);
        printf("<PROCESSO P1> Valori inviati a P3 <%d> <%d> <%d> <%d>\n",vett[2],vett[3],vett[4],vett[5]);

        //INVIO AL PROCESSO P4
        msg.type = P4_TYPE;
        for(int i=0;i<2;i++){
            msg.buffer[i] = vett[i+k];
        }
        msgsnd(queue_1,(void*)&msg,sizeof(Message)-sizeof(long),0);
        printf("<PROCESSO P1> Valori inviati a P4 <%d> <%d>\n",vett[6],vett[7]);


        //RICEVO RISULTATI DAI PROCESSI
        
        int tmp=0,var;
        while(tmp!=3){
            if(ris[0]==0){
                var = msgrcv(queue_2,(void*)&msg_ris,sizeof(Message_ris)-sizeof(long),P2_TYPE,IPC_NOWAIT);
                if(var!=-1){
                    ris[0] = msg_ris.ris;
                    printf("Ricevuto risultato da P2 <%d>\n",ris[0]);
                    tmp++;
                }
            }
            if(ris[1]==0){
                var = msgrcv(queue_2,(void*)&msg_ris,sizeof(Message_ris)-sizeof(long),P3_TYPE,IPC_NOWAIT);
                if(var!=-1){
                    ris[1] = msg_ris.ris;
                    printf("Ricevuto risultato da P3 <%d>\n",ris[1]);
                    tmp++;
                }
            }
            if(ris[2]==0){
                var = msgrcv(queue_2,(void*)&msg_ris,sizeof(Message_ris)-sizeof(long),P4_TYPE,IPC_NOWAIT);
                if(var!=-1){
                    ris[2] = msg_ris.ris;
                    printf("Ricevuto risultato da P4 <%d>\n",ris[2]);
                    tmp++;
                }
            }
        }

        //CALCOLO E STAMPO RISULTATO
        for(int i=1;i<NUM_RIS_P1;i++){
            ris[0] = ris[0]+ris[i];
        }
        printf("RISULTATO FINALE <%d>\n",ris[0]);
    }
    return 0;
}
