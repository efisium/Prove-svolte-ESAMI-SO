#ifndef _HEAD_
#define _HEAD_

#include <stdio.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <time.h>
#include <string.h>

#define DIM_BUFFER 4
#define NUM_PROCESSI 6
#define NUM_OPERANDI 8
#define P2_TYPE 2
#define P3_TYPE 3
#define P4_TYPE 4
#define P5_TYPE 5
#define P6_TYPE 6
#define NUM_RIS_P1 3
#define NUM_RIS_P3 2

typedef struct{
    long type;
    int buffer[DIM_BUFFER];
}Message;

typedef struct{
    long type;
    int ris;
}Message_ris;

#endif