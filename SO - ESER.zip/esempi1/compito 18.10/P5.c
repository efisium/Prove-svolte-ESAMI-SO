#include "header.h"

int main(){
    //QUEUES
    key_t key_1 = ftok(".",'a');
    key_t key_2 = ftok(".",'b');

    int queue_1 = msgget(key_1,IPC_CREAT|0664);
    int queue_2 = msgget(key_2,IPC_CREAT|0664);

    for(int j=0;j<3;j++){
        int ris=0;
        Message msg;
        Message_ris msg_ris;
        msgrcv(queue_1,(void*)&msg,sizeof(Message)-sizeof(long),P5_TYPE,0);
        for(int i=0;i<2;i++){
            ris = ris+msg.buffer[i];
        }
        printf("<PROCESSO P5> Ris %d\n",ris);
        msg_ris.type = P5_TYPE;
        msg_ris.ris = ris;
        msgsnd(queue_2,(void*)&msg_ris,sizeof(Message_ris)-sizeof(long),0);
    }
    return 0;
}