#include "header.h"

int main(){
    pid_t pid;
    int status;

    //QUEUES
    key_t key_1 = ftok(".",'a');
    key_t key_2 = ftok(".",'b');

    int queue_1 = msgget(key_1,IPC_CREAT|0664);
    int queue_2 = msgget(key_2,IPC_CREAT|0664);

    //GENERO PROCESSI
    //P1
    pid = fork();
    if(pid==0){
        execl("./P1_exe","./P1_exe",NULL);
        perror("Errore EXEC\n");
        exit(1);
    }

    //P2
    pid = fork();
    if(pid==0){
        execl("./P2_exe","./P2_exe",NULL);
        perror("Errore EXEC\n");
        exit(1);
    }

    //P3
    pid = fork();
    if(pid==0){
        execl("./P3_exe","./P3_exe",NULL);
        perror("Errore EXEC\n");
        exit(1);
    }

    //P4
    pid = fork();
    if(pid==0){
        execl("./P4_exe","./P4_exe",NULL);
        perror("Errore EXEC\n");
        exit(1);
    }

    //P5
    pid = fork();
    if(pid==0){
        execl("./P5_exe","./P5_exe",NULL);
        perror("Errore EXEC\n");
        exit(1);
    }

    //P6
    pid = fork();
    if(pid==0){
        execl("./P6_exe","./P6_exe",NULL);
        perror("Errore EXEC\n");
        exit(1);
    }

    for(int i=0;i<NUM_PROCESSI;i++){
        pid = wait(&status);
        if(pid<0){
            perror("WAIT ERROR\n");
            exit(1);
        }
        printf("Processo %d terminato con stato [%d]\n",pid,status);
    }
    
    msgctl(queue_1,IPC_RMID,0);
    msgctl(queue_2,IPC_RMID,0);

    return 0;
}