#include "header.h"

int main(){
    //QUEUES
    key_t key_1 = ftok(".",'a');
    key_t key_2 = ftok(".",'b');

    int queue_1 = msgget(key_1,IPC_CREAT|0664);
    int queue_2 = msgget(key_2,IPC_CREAT|0664);

    int vett_1[4];
    int ris[NUM_RIS_P3];
    Message msg;
    Message_ris msg_ris;

    for(int j=0;j<3;j++){
        msgrcv(queue_1,(void*)&msg,sizeof(Message)-sizeof(long),P3_TYPE,0);
        for(int i=0;i<4;i++){
            vett_1[i] = msg.buffer[i];
        }
        for(int i=0;i<NUM_RIS_P3;i++){
            ris[i] = 0;
        }

        //INVIO AL PROCESSO P5
        msg.type = P5_TYPE;
        for(int i=0;i<2;i++){
            msg.buffer[i] = vett_1[i];
        }
        msgsnd(queue_1,(void*)&msg,sizeof(Message)-sizeof(long),0);
        printf("<PROCESSO P3> Valori inviati a P5 <%d> <%d>\n",vett_1[0],vett_1[1]);

        //INVIO AL PROCESSO P6
        msg.type = P6_TYPE;
        for(int i=0;i<2;i++){
            msg.buffer[i] = vett_1[i+2];
        }
        msgsnd(queue_1,(void*)&msg,sizeof(Message)-sizeof(long),0);
        printf("<PROCESSO P3> Valori inviati a P6 <%d> <%d>\n",vett_1[2],vett_1[3]);

        int tmp = 0,var;
        while(tmp!=2){
            if(ris[0]==0){
                var = msgrcv(queue_2,(void*)&msg_ris,sizeof(Message_ris)-sizeof(long),P5_TYPE,IPC_NOWAIT);
                if(var!=-1){
                    ris[0] = msg_ris.ris;
                    printf("Ricevuto risultato da P5 <%d>\n",ris[0]);
                    tmp++;
                }
            }
            if(ris[1]==0){
                var = msgrcv(queue_2,(void*)&msg_ris,sizeof(Message_ris)-sizeof(long),P6_TYPE,IPC_NOWAIT);
                if(var!=-1){
                    ris[1] = msg_ris.ris;
                    printf("Ricevuto risultato da P6 <%d>\n",ris[1]);
                    tmp++;
                }
            }
        }

        //CALCOLO RISULTATO
        ris[0] = ris[0]*ris[1];

        printf("<PROCESSO P3> Ris %d\n",ris[0]);
        msg_ris.type = P3_TYPE;
        msg_ris.ris = ris[0];
        msgsnd(queue_2,(void*)&msg_ris,sizeof(Message_ris)-sizeof(long),0);
    }
    return 0;
}