				/*-----HEADER FILE----*/
#include <stdio.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <string.h>

#ifndef __HEADER
#define __HEADER
#define MESSAGGIO 1


typedef char msg [40];

typedef struct {
		long tipo;
		msg mess;
} Messaggio;

void Produttore(int queue,char* m,char *coda);
void Consumatore(int queue,char *coda);
void printMsgInfo(int queue);
#endif



