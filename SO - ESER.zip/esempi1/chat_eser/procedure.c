			/*-----IMPLEMENTAZIONE DELLE PROCEDURE-----*/
#include "header.h"

void Produttore(int queue, char * text,char *coda) {
	Messaggio m;
	// costruzione del messaggio da trasmettere
	m.tipo=MESSAGGIO;
	strcpy(m.mess,text); 
	// invio messaggio
	msgsnd(queue,(void*)&m,sizeof(Messaggio)-sizeof(long),IPC_NOWAIT);
	printf("MESSAGGIO INVIATO sulla coda %s  Testo messaggio: <%s>\n",coda,m.mess);
}

void Consumatore(int queue,char *coda) {
	Messaggio m;
	// ricezione messaggio
	msgrcv(queue,(void *) &m,sizeof(Messaggio)-sizeof(long),MESSAGGIO,0);
	printf("MESSAGGIO RICEVUTO sulla coda %s  Testo messaggio: <%s>\n",coda,m.mess);
	if(strcmp(m.mess,"exit")==0){
		exit(1);
	}
}

/*void printMsgInfo(int queue){
	struct msqid_ds mid;
	msgctl(queue,IPC_STAT,&mid);	
	char *time_sender = ctime(&mid.msg_stime);
	char *time_receiver = ctime(&mid.msg_rtime);	
	char *time_ctime = ctime(&mid.msg_ctime);
	printf("Time Sender: %sTime Receiver: %sTime Ctime: %s",time_sender,time_receiver,time_ctime);
	printf("Messages Number: %lu\n",mid.msg_qnum);
}*/
