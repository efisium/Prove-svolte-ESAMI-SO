#include "header.h"

int main(int argc,char *argv[]){

	int k,status,queue1,queue2;
	pid_t pid;
	int i;
	char m[30];
    printf("Argomenti %s %s\n",argv[1],argv[2]);
    key_t key_1 = ftok("./client_exe",*argv[1]); 
    if(key_1<0){
        perror("ERRORE");
    }
    key_t key_2 = ftok("./client_exe",*argv[2]);
    printf("Valori key %d %d\n",key_1,key_2);
	// assegnazione coda di comunicazione
	queue1=msgget(key_1,IPC_CREAT|IPC_EXCL|0664); //CODA A CON CHIAVE 1
    if(queue1<0){
        queue1=msgget(key_1,0664);
    }
    queue2=msgget(key_2,IPC_CREAT|IPC_EXCL|0664); //CODA B CON CHIAVE 2
    if(queue2<0){
        queue2=msgget(key_2,0664);
    }
    printf("Valore coda %d %d\n",queue1,queue2);
	// generazione produttore e consumatore
	pid=fork();
	if (pid==0){			//processo figlio RICEVENTE
		printf("Sono il MITTENTE. Il mio pid %d \n",getpid());
		
        while(1){	
            printf("Inserisci il messaggio da inviare sulla coda %s\n",argv[1]);
			scanf("%s",m);
            
            Produttore(queue1,m,argv[1]);
            if(strcmp(m,"exit") == 0){
                exit(0);
            }
		}
	}else{
		pid=fork();		//genera figlio RICEVENTE
	 	if (pid==0){
            while(1){	
                printf("Ricezione sulla coda %s\n\n",argv[2]);
                Consumatore(queue2,argv[2]);
            }
	    }
    }
	// attesa di terminazione
	for (k=0; k<2;k++){
		pid=wait(&status);
		if (pid==-1)
			perror("errore");
		else
			printf ("Figlio n.ro %d e\' morto con status= %d\n",pid,status>>8);
	}

	// deallocazione code
	msgctl(queue1,IPC_RMID,0);
    msgctl(queue2,IPC_RMID,0);	
	return 0;
}
