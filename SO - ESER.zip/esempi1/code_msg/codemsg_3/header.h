
#ifndef _HEAD_H_
#define _HEAD_H_

#include <stdio.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <string.h>
#include <sys/ipc.h>
#include <time.h>

				/*-----HEADER FILE----*/

#define REQUEST_TO_SEND 1
#define OK_TO_SEND 2
#define MESSAGGIO1 3
#define MESSAGGIO2 4
#define MIN 5
#define MAX 10

typedef char msg [40];

typedef struct {
		long tipo;
		msg mess;
		float val;
		} Messaggio;

void ReceiveBloc (Messaggio *, int,int);
void SendSincr (Messaggio *, int);
void initServiceQueues();
void removeServiceQueues();

void Produttore(int queue, char *,float,int);
void Consumatore(int queue,float*);
float random_f();

#endif