#include "header.h"

int main(){
    printf("Esecuzione Processo P2...\n");
    int status,queue;
	pid_t pid;
    key_t key_queue;

    key_queue = ftok("./exe",'q');


	// assegnazione coda di comunicazione
	queue=msgget(key_queue,0664);

	printf("Sono il Processo P2. Il mio pid %d \n",getpid());
	    
	char str[3];
	sprintf(str,"P%d",2);
    float rnd_value;
    for(int i = 0;i<2;i++){
        sleep(2); 
		rnd_value = random_f();
		Produttore(queue,str,rnd_value,MESSAGGIO2);
	}
    return 0;
}