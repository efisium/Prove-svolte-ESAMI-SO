			/*-----IMPLEMENTAZIONE DELLE PROCEDURE-----*/
#include "header.h"

static int queue1;//statiche-->non � necessaria la loro visibilit� fuori dal modulo
static int queue2;
static key_t k1;
static key_t k2;

// inizializzazione code di servizio
void initServiceQueues(){

	k1 = ftok(".",'a');
	k2 = ftok(".",'b');
    queue1=msgget(k1,IPC_CREAT|0664);
	queue2=msgget(k2,IPC_CREAT|0664);
}

// rimozione code di servizio
void removeServiceQueues(){
	msgctl(queue1,IPC_RMID,0);
	msgctl(queue2,IPC_RMID,0);
}

// Send Sincrona
void SendSincr (Messaggio *m , int queue){
	Messaggio m1,m2;
	// costruzione messaggio RTS
	m1.tipo=REQUEST_TO_SEND;
	strcpy(m1.mess,"Richiesta di invio");
	// invio messaggio RTS
	msgsnd(queue1,&m1,sizeof(Messaggio)-sizeof(long),0);	
	// ricezione OTS
	msgrcv(queue2,&m2,sizeof(Messaggio)-sizeof(long),OK_TO_SEND,0);
	// invio messaggio
	msgsnd(queue,m,sizeof(Messaggio)-sizeof(long),0);
}

// Receive Bloccante
void ReceiveBloc (Messaggio *m, int queue, int tipomess){
	Messaggio m1,m2;	// ricezione messaggio RTS
	//printf("attendo q1\n");
	msgrcv(queue1,&m1,sizeof(Messaggio)-sizeof(long),REQUEST_TO_SEND,0);	// costruzione messaggio OTS
	//printf("mando mex su q2\n");
	m2.tipo=OK_TO_SEND;
	strcpy(m2.mess,"Ready to send");
	// invio messaggio OTS
	msgsnd(queue2,&m2,sizeof(Messaggio)-sizeof(long),0);
	// ricezione messaggio
	msgrcv(queue,m,sizeof(Messaggio)-sizeof(long),tipomess,0);
}

void Produttore(int queue, char * text,float valore,int type) {
	Messaggio m;
	// costruzione del messaggio da trasmettere
	m.tipo=type;
	strcpy(m.mess,text); 
	m.val = valore;
	printf("Invio messaggio: TEXT: %s, VAL: %f\n",m.mess,m.val);
	// invio messaggio
	SendSincr(&m,queue);
	//printf("MESSAGGIO INVIATO: <%s>\n",m.mess);
}

void Consumatore(int queue,float *media) {
	Messaggio m;
	// ricezione messaggio
	//printf("avvio receive bloccante\n");
	ReceiveBloc(&m,queue,0);
	printf("MESSAGGIO RICEVUTO: Processo:<%s>, Valore: %f\n",m.mess,m.val);
	// calcolo media
	if(m.tipo == MESSAGGIO2){
		media[1] = ((media[1]+m.val)/2);
	}else if(m.tipo == MESSAGGIO1){
		media[0] = ((media[0]+m.val)/2);
	}
}

float random_f(){
	srand(time(NULL));
	float val = MIN + rand() % (MAX);
	return val;
}


