#include "header.h"

int main(){
    int k,status,queue;
	pid_t pid;
    key_t key_queue;

    key_queue = ftok("./exe",'q');

	// assegnazione coda di comunicazione
	queue=msgget(key_queue,IPC_CREAT|0664);

	// inizializzazione code di servizio
	initServiceQueues();

    pid=fork();
	if (pid==0)  {		
		printf("Sono il Processo P3. Il mio pid %d \n",getpid());
		sleep(2);
		execl("./P3_exe","./P3_exe",NULL);
	}else{ 
        pid=fork();		
        if (pid==0){
            printf("Sono il Processo P1. Il mio pid %d \n",getpid());
            sleep(1);
            execl("./P1_exe","./P1_exe",NULL);
        }else{
            pid=fork();
            if(pid==0){
                printf("Sono il Processo P2. Il mio pid %d \n",getpid());
                sleep(1);
                execl("./P2_exe","./P2_exe",NULL);
            }
        }
	}

	// attesa di terminazione
	for (k=0; k<3;k++){
		pid=wait(&status);
		if (pid==-1)
			perror("errore");
		else
			printf ("Figlio n.ro %d e\' morto con status= %d\n",pid,status>>8);
	}

	// deallocazione code
	msgctl(queue,IPC_RMID,0);
	removeServiceQueues();
	
	return 0;
}