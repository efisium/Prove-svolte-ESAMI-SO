#include "header.h"

int main(){
    printf("Esecuzione Processo P3...\n");
    int status,queue;
    float val[2];
	pid_t pid;
    key_t key_queue;

    key_queue = ftok("./exe",'q');


	// assegnazione coda di comunicazione
	queue=msgget(key_queue,0664);

    		
    printf("Sono il Processo P3. Il mio pid %d \n",getpid());
	int type;
    for(int i = 0;i<4;i++){
        
        float tmp;
        sleep(2);
	    Consumatore(queue,val);
        
    }
    printf("Media finale calcolata: 1: <%f> 2: <%f>\n",val[0],val[1]);
    return 0;
}