#include <sys/msg.h>
#include "header.h"

void Sender(int id_queue_receiver,int id_queue_sender){
    while(1){
        //imposto il msg
        //check il msg "exit"
        //nel caso invio il messaggio sulla coda del sender
    }
}

void Receiver(int id_queue_receiver){
    while(1){
        //attendi un msg dulla coda receiver
        //
    }
}

int main(int argc,char *argv[])
{
    char firstChar = *argv[1];
    char secondChar = *argv[2];

    //definire chiavi per le code
    key_t queue_sender = ftok("./exe",firstChar);
    key_t queue_receiver = ftok("./exe",secondChar);

    //descrittori
    int id_queue_sender = msgget(queue_sender,IPC_CREAT|0664);
    int id_queue_receiver = msgget(queue_receiver,IPC_CREAT|0664);
    //CHECK descrittori >0
    
    //genero il sender e il receiver tramite fork
    // 
    return 0;
}