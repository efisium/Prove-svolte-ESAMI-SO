#include "header.h"

int main(){
    pid_t pid;
    int status;

    //SHM
    key_t shm_key = IPC_PRIVATE;
    int shm_id = shmget(shm_key,sizeof(Buffer),IPC_CREAT|0664);
    Buffer* p = (Buffer*)shmat(shm_id,NULL,0);
    init_var(p);

    //Genero processi
    //SCHEDULER
    pid = fork();
    if(pid==0){
        auto richiesta disco[DIM_DISCO];
        printf("Avvio Schedulatore %d...\n",getpid());
        richiesta r;
        int p_i = 0,t;
        for(int i=0;i<25;i++){
            r = Schedula(p);
            t = r.posizione + p_i;
            p_i = r.posizione;
            sleep(t);
            printf("[SCHEDULER] Ricevuta richiesta %d. Tempo di attesa: %ds\n",i,t);
            disco[r.posizione] = r;
            printf("[SCHEDULER] Sovrascrivo nella poszione %d del disco la richiesta: PID <%d> POSIZIONE <%d>\n",p_i,r.processo,r.posizione);
        }
        exit(0);
    }
    //UTENTI
    for(int i=0;i<N_UTENTI;i++){
        pid = fork();
        if(pid == 0){
            printf("Avvio Utente %d...\n",getpid());
            richiesta r;
            r.processo = getpid();
            for(int k=0;k<5;k++){
                srand(getpid()*k*i);
                r.posizione = rand()%20;
                GeneraRichiesta(p,r);
                printf("[UTENTE %d] Generata richiesta n.%d PID <%d> POSIZIONE <%d>\n",i,k,r.processo,r.posizione);
            }
            exit(0);
        }
    }

    for(int i=0;i<N_UTENTI+1;i++){
        pid = wait(&status);
        if(pid<0){
            perror("WAIT ERROR\n");
            exit(1);
        }
        printf("Processo %d terminato con stato: %d\n",pid,status);
    }
    remove_var(p);
    shmctl(shm_id,IPC_RMID,0);
    return 0;
}