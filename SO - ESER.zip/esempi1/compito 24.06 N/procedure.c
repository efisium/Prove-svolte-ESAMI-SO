#include "header.h"

void init_var(Buffer *p){
    init_monitor(&(p->m),2);
    p->testa = 0;
    p->cont = 0;
    p->coda = 0;
}

void remove_var(Buffer *p){
    remove_monitor(&(p->m));
}

void GeneraRichiesta(Buffer *p,richiesta r){
    enter_monitor(&(p->m));
    if(p->cont == DIM_BUFFER){
        wait_condition(&(p->m),VARCOND_PROD);
    }

    p->b[p->coda] = r;
    p->coda = (p->coda +1) % DIM_BUFFER;
    (p->cont)++;

    signal_condition(&(p->m),VARCOND_CONS);
    leave_monitor(&(p->m));
}

richiesta Schedula(Buffer *p){
    enter_monitor(&(p->m));
    if(p->cont == 0){
        wait_condition(&(p->m),VARCOND_CONS);
    }

    richiesta r = p->b[p->testa];
    p->testa = (p->testa +1) % DIM_BUFFER;
    (p->cont)--;

    signal_condition(&(p->m),VARCOND_PROD);
    leave_monitor(&(p->m));
    return r;
}