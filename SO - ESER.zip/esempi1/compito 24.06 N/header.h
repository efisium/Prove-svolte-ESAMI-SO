#ifndef _HEAD_
#define _HEAD_

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include "monitor_hoare.h"

#define DIM_BUFFER 10
#define DIM_DISCO 20
#define N_UTENTI 5
#define VARCOND_PROD 0
#define VARCOND_CONS 1


typedef struct {
unsigned int posizione;
pid_t processo;
} richiesta;

typedef struct{

    richiesta b[DIM_BUFFER];
    int testa;
    int coda;
    int cont;

    Monitor m;
}Buffer;

void init_var(Buffer* p);
void remove_var(Buffer* p);
void GeneraRichiesta(Buffer *p,richiesta r);
richiesta Schedula(Buffer *p);

#endif