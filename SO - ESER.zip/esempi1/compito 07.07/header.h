#ifndef _HEAD_
#define _HEAD_

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <errno.h>
#include <pthread.h>

#define N_PROD 5
#define DIM_STACK 4

typedef int Elem;
typedef struct Stack {
    Elem * dati;    // puntatore ad un vettore dinamico di elementi
    int dim;  // dimensione dello Stack
    // variabili da aggiungere per la sincronizzazione
    pthread_mutex_t mutex;
    pthread_cond_t ok_stack_push;
    pthread_cond_t ok_stack_wait;
    pthread_cond_t ok_stack_pop;
    pthread_cond_t ok_size;

    int stack_size_wait;
    int cons;
    int prod;
    int stack_pop_wait;
    int stack_push_wait;
} Stack;


void StackInit(Stack * s, int dim); 
void StackRemove(Stack * s);
void StackPush(Stack * s, Elem e); 
Elem StackPop(Stack * s);
int StackSize(Stack * s);
void* start_prod(void *g);
void* start_cons(void *g);

#endif