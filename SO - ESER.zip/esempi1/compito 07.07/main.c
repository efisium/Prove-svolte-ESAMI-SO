#include "header.h"

int main(){
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_JOINABLE);

    pthread_t Prod[N_PROD];
    pthread_t Cons;

    Stack *s = (Stack*)malloc(sizeof(Stack));
    //StackInit(s,DIM_STACK);
    s->dati = malloc(DIM_STACK * sizeof(Elem));
    s->dim = 0;
    s->stack_pop_wait = 0;
    s->stack_push_wait = 0;
    s->stack_size_wait = 0;
    s->prod = 0;
    s->cons = 0;
    printf("Inizio init..\n");
    pthread_mutex_init(&s->mutex,NULL);
    pthread_cond_init(&s->ok_stack_push,NULL);
    pthread_cond_init(&s->ok_stack_wait,NULL);
    pthread_cond_init(&s->ok_stack_pop,NULL);
    pthread_cond_init(&s->ok_size,NULL);

    //CREAZIONE THREAD
    for(int i=0;i<N_PROD;i++){
        pthread_create(&Prod[i],&attr,start_prod,(void*)&s);
    }
    pthread_create(&Cons,&attr,start_cons,(void*)&s);

    //JOIN THREAD
    for(int i=0;i<N_PROD;i++){
        pthread_join(Prod[i],NULL);
        printf("Thread Produttore %d terminato.\n",i);
    }
    pthread_join(Cons,NULL);
    printf("Thread Consumatore terminato.\n");

    pthread_mutex_destroy(&s->mutex);
    pthread_cond_destroy(&s->ok_stack_push);
    pthread_cond_destroy(&s->ok_stack_wait);
    pthread_cond_destroy(&s->ok_stack_pop);
    pthread_attr_destroy(&attr);
    printf("FINE.\n");
    pthread_exit(NULL);
    return 0;
}