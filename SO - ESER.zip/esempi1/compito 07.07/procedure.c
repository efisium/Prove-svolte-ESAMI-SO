#include "header.h"
void StackInit(Stack * s, int dim){
    s->dati = malloc(dim * sizeof(Elem));
} 
void StackRemove(Stack * s){
    free(s->dati);
}
void StackPush(Stack * s, Elem e){
    pthread_mutex_lock(&s->mutex);
    if(s->prod == 1 || s->cons ==1){
        pthread_cond_wait(&s->ok_stack_wait,&s->mutex);
    }
    if(s->dim == DIM_STACK){
        s->stack_push_wait++;
        printf("Stack pieno! Attendo il pop... \n");
        pthread_cond_wait(&s->ok_stack_push,&s->mutex);
        s->stack_push_wait--;
    }
    (s->prod)++;
    pthread_mutex_unlock(&s->mutex);

    s->dati[s->dim] = e;
    (s->dim)++;

    pthread_mutex_lock(&s->mutex);
    (s->prod)--;
    if(s->stack_pop_wait>0){
        pthread_cond_signal(&s->ok_stack_pop);
    }
    pthread_mutex_unlock(&s->mutex);
}
Elem StackPop(Stack * s){
    pthread_mutex_lock(&s->mutex);
    if(s->prod == 1 || s->cons ==1){
        pthread_cond_wait(&s->ok_stack_wait,&s->mutex);
    }
    if(s->dim == 0){
        s->stack_pop_wait++;
        printf("Stack vuoto! Attendo il push... \n");
        pthread_cond_wait(&s->ok_stack_pop,&s->mutex);
        s->stack_pop_wait--;
    }
    (s->prod)++;
    pthread_mutex_unlock(&s->mutex);

    Elem e = s->dati[s->dim-1];
    (s->dim)--;

    pthread_mutex_lock(&s->mutex);
    (s->prod)--;
    if(s->stack_push_wait>0){
        pthread_cond_signal(&s->ok_stack_push);
    }
    pthread_mutex_unlock(&s->mutex);
    return e;
}
int StackSize(Stack * s){
    return s->dim;
}
void* start_prod(void *g){
    printf("Avvio thread produttore...\n");
    Stack*s=(Stack*)g;
    Elem var;
    for(int i=0;i<4;i++){
        sleep(1);
        srand(time(NULL)*i);
        var = rand()%11;
        StackPush(s,var);
    }
    pthread_exit(NULL);
}
void* start_cons(void *g){
    printf("Avvio thread consumatore...\n");
    /*Stack*s=(Stack*)g;
    Elem var;
    for(int i=0;i<10;i++){
        var = 0;
        for(int j=0;j<2;j++){
            var = var + StackPop(s);
        }
        printf("[CONS] Somma valori stack <%d>\n",var);
    }*/
    pthread_exit(NULL);

}