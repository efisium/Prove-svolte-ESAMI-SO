#include "header.h"

int main(){
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_JOINABLE);

    //THREADS PRODUTTORI
    pthread_t thread_prod[NUM_THREADS_PROD];

    //THREADS CONSUMATORI
    pthread_t thread_cons[NUM_THREADS_CONS];

    //Creazione istanza struttura monitor
    GestioneIO* pc = malloc(sizeof(GestioneIO));
    
    pc->testa = 0;
    pc->coda = 0;
    pc->cont = 0;

    Inizializza(pc);
    printf("BONASEE'\n");

    //PRODUTTORI
    int k;
    for(k=0;k<NUM_THREADS_PROD;k++){
        pthread_create(&thread_prod[k],&attr,Produttore,(void*)pc);
    }

    //CONSUMATORI
    int i;
    for(i=0;i<NUM_THREADS_CONS;i++){
        pthread_create(&thread_prod[i],&attr,Consumatore,(void*)pc);
    }

    //JOIN DEI THREADS
    for(k=0;k<NUM_THREADS_PROD;k++){
        pthread_join(thread_prod[k],NULL);
        printf ("Thread PROD n.ro %d terminato\n ",k);
    }

    for(i=0;i<NUM_THREADS_CONS;i++){
        pthread_join(thread_cons[i],NULL);
        printf ("Thread CONS n.ro %d terminato\n ",i);
    }

    pthread_attr_destroy(&attr);
    pthread_mutex_destroy(&pc->mutex);
    pthread_cond_destroy(&pc->ok_prod_cv);
    pthread_cond_destroy(&pc->ok_cons_cv);
    pthread_exit(NULL);
    return 0;

}