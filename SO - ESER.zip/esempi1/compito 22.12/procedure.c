#include "header.h"

void Inizializza(GestioneIO* pc){
    //INIT MUTEX E VARCOND
    pthread_mutex_init(&pc->mutex,NULL);
    pthread_cond_init(&pc->ok_prod_cv,NULL);
    pthread_cond_init(&pc->ok_cons_cv,NULL);

    //INIT VAR. STATO
    pc->ok_produzione = 1;
    pc->ok_consumo = 0;
}

void Produci(GestioneIO* g, Buffer* b){
    InizioProduzione(g);
    g->vettore[g->testa] = (*b);
    g->testa = ((g->testa) + 1) % DIM_BUFFER;
    FineProduzione(g);
}
int Consuma(GestioneIO* g, Buffer* b){
    if(g->cont == 0){ 
        return 1;
    }else{
        (*b) = g->vettore[g->coda];
        g->coda = ((g->coda) + 1) % DIM_BUFFER;
        (g->cont)--;
        printf("Cont-- <%d>\n",g->cont);
        return 0;
    }
}

void* Produttore(void* p){
    GestioneIO* g = (GestioneIO *)p;
    int indirizzo_tmp;
    int dato_tmp;
    srand(time(NULL));
    indirizzo_tmp = rand()%11;
    dato_tmp = rand()%11;
    Buffer b_tmp;
    b_tmp.dato = dato_tmp;
    b_tmp.indirizzo = indirizzo_tmp;
    
    for(int i=0;i<3;i++){
        printf("Iterazione PROD n.%d\n",i);
        sleep(1);
        Produci(g,&b_tmp);
        printf("Valore prodotto: [%d] [%d]\n",b_tmp.dato,b_tmp.indirizzo);
        
        (b_tmp.dato)++;
        (b_tmp.indirizzo)++;
    }
    pthread_exit(NULL);
}
void* Consumatore(void* p){
    GestioneIO* g = (GestioneIO *)p;
    int var;
    Buffer tmp;
    for(int i=0;i<4;i++){
        printf("Iterazione CONS n.%d\n",i);
        var = 0;
        sleep(3);
        InizioConsumo(g);
        while(var == 0){
            var = Consuma(g,&tmp);
            if(var == 1) continue;
            printf("Valore VAR: %d    ",var);
            printf("Valori consumati: [%d] [%d]\n",tmp.dato,tmp.indirizzo);
        }
        FineConsumo(g);
    }
    printf("Sono un consumatore e muoio\n");
    pthread_exit(NULL);
}

void InizioProduzione(GestioneIO* g){
    pthread_mutex_lock(&g->mutex);

    while(g->cont == DIM_BUFFER){
        pthread_cond_wait(&g->ok_prod_cv,&g->mutex);
    }
}

void FineProduzione(GestioneIO* g){
    (g->cont)++;
    printf("Cont++ <%d>\n",g->cont);
    pthread_cond_signal(&g->ok_cons_cv);
    pthread_mutex_unlock(&g->mutex);
}

void InizioConsumo(GestioneIO* g){
    pthread_mutex_lock(&g->mutex);
}

int FineConsumo(GestioneIO* g){
    pthread_cond_signal(&g->ok_prod_cv);
    pthread_mutex_unlock(&g->mutex);
    return 0;
}