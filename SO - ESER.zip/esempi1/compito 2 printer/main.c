#include "header.h"

int main(){

    //KEY MESSAGE QUEUE
    key_t msg_key = IPC_PRIVATE;

    //GENERO CODA MESSAGGI
    int queue = msgget(msg_key,IPC_CREAT|0664);
    if(queue<0) perror("ERRORE CREAZIONE CODA");
}