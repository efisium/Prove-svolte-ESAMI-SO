#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <errno.h>

#include "header.h"


void generatore_produttore(struct ProdConsGen *pc){
        
    /* TODO: utilizzare il costrutto monitor per la produzione del messaggio */
    enter_monitor( &(pc->m) );
    while( pc->cont == DIM_QUEUE) {
		//printf("Sospensione produzione\n");
		wait_condition( &(pc->m), VARCOND_GEN_PRODUTTORI);
		//printf("Riattivazione produzione\n");
	}

    message msg;

    //GENERAZIONE MESSAGGIO /*******************
    msg.type = MSG_TYPE;
    
    //Assegnazione stringa
    int dim_str = 1+rand()%10;
    for(int j=0;j<(dim_str);j++){
        msg.stringa[j] = ('a' +(rand()%26));
    }
    msg.stringa[dim_str+1] = '\0';
    
    //Array di interi
    for(int i=0;i<2;i++){
        msg.mat[i] = rand()%10;
    }

    //Variabile intera
    msg.valore = 0;
    //printf("Valore: %d\n",msg.valore);

    pc->buffer[pc->testa] = msg;
    
    pc->testa = (pc->testa+1) % DIM_QUEUE;

    printf("[generatore_produttore] Messaggio generato!\n");
    printf("[generatore_produttore] ...............msg.stringa: %s\n", msg.stringa);
    printf("[generatore_produttore] ...............msg.array[0]: %d\n", msg.mat[0]);
    printf("[generatore_produttore] ...............msg.array[1]: %d\n", msg.mat[1]);
    printf("[generatore_produttore] ...............msg.var: %d\n", msg.valore);
    
    (pc->cont)++;
    printf("Variabile cont = %d\n",pc->cont);
    signal_condition(&(pc->m),VARCOND_GEN_CONSUMATORI);
    leave_monitor(&(pc->m));
}

void generatore_consumatore(struct ProdConsGen *pc, int ds_queue_gen_filter){

    /* TODO: utilizzare il costrutto monitor per la consumazione del messaggio e l'invio verso il processo filter */
    enter_monitor( &(pc->m) );
    while( pc->cont == 0 ) {
		//printf("Sospensione produzione\n");
		wait_condition( &(pc->m), VARCOND_GEN_CONSUMATORI);
		//printf("Riattivazione produzione\n");
	}

    printf("[generatore_consumatore] Messaggio CONSUMATO!\n");
    printf("[generatore_consumatore] ...............msg.stringa: %s\n", pc->buffer[pc->coda].stringa);
    printf("[generatore_consumatore] ...............msg.array[0]: %d\n", pc->buffer[pc->coda].mat[0]);
    printf("[generatore_consumatore] ...............msg.array[1]: %d\n", pc->buffer[pc->coda].mat[1]);
    printf("[generatore_consumatore] ...............msg.var: %d\n", pc->buffer[pc->coda].valore);
    
    pc->coda = (pc->coda + 1) % DIM_QUEUE;
    (pc->cont)--;
    printf("Variabile cont = %d\n",pc->cont);
    int ret = msgsnd(ds_queue_gen_filter,(void*)&(pc->buffer[pc->coda]),sizeof(message)-sizeof(long),IPC_NOWAIT);
    
    if (ret<0){
            perror("msgsnd del messaggio on ds_queue_gen_filter FALLITA!");
            exit(-1);
    }
    printf("[generatore_consumatore] Messaggio INVIATO!\n");
    
    signal_condition(&(pc->m),VARCOND_GEN_PRODUTTORI);
    leave_monitor(&(pc->m));
}

