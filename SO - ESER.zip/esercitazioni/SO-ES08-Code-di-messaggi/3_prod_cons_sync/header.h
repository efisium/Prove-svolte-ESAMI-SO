#include <stdio.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <string.h>

				/*-----HEADER FILE----*/

#define REQUEST_TO_SEND 1
#define OK_TO_SEND 2
#define MESSAGGIO 3

typedef char msg [2];

typedef struct {
		long tipo;
		msg mess;
		float val;
		} Messaggio;

void ReceiveBloc (Messaggio *, int,int);
void SendSincr (Messaggio *, int);
void initServiceQueues();
void removeServiceQueues();

void Produttore(int queue, char *);
void Consumatore(int queue);

