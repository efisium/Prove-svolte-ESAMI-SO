#define SPAZIO_DISPONIBILE 0
#define MESSAGGIO_DISPONIBILE 1

void produttore(int *, int);
void consumatore(int *, int);
