//Dichiarazioni prototipi
//legge un vettore dallo standard di input
void leggi_vettore(int [], const int);
//stampa un vettore sullo standard di output
void stampa_vettore(const int [], const int);
//funzione somma_vettori 
void somma_vettori(const int[], const int[], int[], const int);

const int NMAX=30;				//riempimento degli array

