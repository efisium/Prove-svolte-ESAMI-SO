#ifndef __MAT
#define __MAT

int somma(int* s, int d);
int prod(int* s,int d);

#endif
